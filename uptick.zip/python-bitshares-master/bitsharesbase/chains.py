# -*- coding: utf-8 -*-
known_chains = {
    "NBS": {
        "chain_id": "cd931cb96d657ff0ef0226f7ae9d25175b3cc96a84490a674ed36170830324e7",
        "core_symbol": "NBS",
        "prefix": "NBS",
    },
    "TEST": {
        "chain_id": "905413ea3fd7842629fc7a38e81b32603e2a42bca795a95524c95475a7e31404",
        "core_symbol": "TEST",
        "prefix": "TEST",
    },
}
