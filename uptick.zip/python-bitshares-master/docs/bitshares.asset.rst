bitshares.asset module
======================

.. automodule:: bitshares.asset
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
