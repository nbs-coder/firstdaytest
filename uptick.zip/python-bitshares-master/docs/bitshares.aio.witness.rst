bitshares.aio.witness module
============================

.. automodule:: bitshares.aio.witness
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
