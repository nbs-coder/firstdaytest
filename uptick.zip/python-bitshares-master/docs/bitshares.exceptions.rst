bitshares.exceptions module
===========================

.. automodule:: bitshares.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
