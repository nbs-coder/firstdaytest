*********************
Support and Questions
*********************

* https://t.me/pybitshares - dedicated channel
* https://bitsharestalk.org - BitShares forum
* https://t.me/BitSharesDEX - general telegram channel
