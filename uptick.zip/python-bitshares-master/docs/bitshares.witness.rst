bitshares.witness module
========================

.. automodule:: bitshares.witness
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
