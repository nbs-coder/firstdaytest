bitshares.aio.proposal module
=============================

.. automodule:: bitshares.aio.proposal
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
