bitshares.memo module
=====================

.. automodule:: bitshares.memo
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
