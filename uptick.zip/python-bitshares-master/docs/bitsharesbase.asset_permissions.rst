bitsharesbase.asset\_permissions module
=======================================

.. automodule:: bitsharesbase.asset_permissions
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
