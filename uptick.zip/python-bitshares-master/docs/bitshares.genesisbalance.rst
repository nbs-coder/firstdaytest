bitshares.genesisbalance module
===============================

.. automodule:: bitshares.genesisbalance
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
