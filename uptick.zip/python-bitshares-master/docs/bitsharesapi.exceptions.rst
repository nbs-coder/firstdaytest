bitsharesapi.exceptions module
==============================

.. automodule:: bitsharesapi.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
