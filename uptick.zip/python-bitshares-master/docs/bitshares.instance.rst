bitshares.instance module
=========================

.. automodule:: bitshares.instance
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
