bitshares.proposal module
=========================

.. automodule:: bitshares.proposal
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
