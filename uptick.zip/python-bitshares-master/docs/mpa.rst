********************
Market Pegged Assets
********************

Market Pegged Assets are a class of financial instruments available on the
BitShares network. They implement a loan where one party gets stability
with respect to an underlying asset and the other gets leverage against
another digital asset that servers as backing collateral for the first.
