bitshares.aio.genesisbalance module
===================================

.. automodule:: bitshares.aio.genesisbalance
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
