# Changelog
Note: version releases in the 0.x.y range may introduce breaking changes.

## 0.7.0

- minor: Add liquidity pool support

## 0.6.0

- minor: Add support for tickets

## 0.5.1

- patch: Add aio packages to setup.py

## 0.5.0

- minor: Add asyncio support
- minor: Fixes

## 0.4.0

- minor: Ensure we can invert Order and FilledOrder too
- patch: Make Notify terminate on CTRL-C

## 0.3.3

- patch: New docs
- patch: Released with semversioner
- patch: pyup updates

## 0.3.2

- patch: Status Quo

