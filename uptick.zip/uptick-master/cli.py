#!/usr/bin/env python3

from uptick import cli

cli.main()
