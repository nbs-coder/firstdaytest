uptick.ui module
================

.. automodule:: uptick.ui
   :members:
   :undoc-members:
   :show-inheritance:
