uptick.api module
=================

.. automodule:: uptick.api
   :members:
   :undoc-members:
   :show-inheritance:
