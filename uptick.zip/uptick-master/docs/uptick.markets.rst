uptick.markets module
=====================

.. automodule:: uptick.markets
   :members:
   :undoc-members:
   :show-inheritance:
