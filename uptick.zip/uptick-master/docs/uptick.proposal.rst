uptick.proposal module
======================

.. automodule:: uptick.proposal
   :members:
   :undoc-members:
   :show-inheritance:
