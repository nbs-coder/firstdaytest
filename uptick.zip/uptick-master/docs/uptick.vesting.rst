uptick.vesting module
=====================

.. automodule:: uptick.vesting
   :members:
   :undoc-members:
   :show-inheritance:
