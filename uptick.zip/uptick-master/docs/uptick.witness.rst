uptick.witness module
=====================

.. automodule:: uptick.witness
   :members:
   :undoc-members:
   :show-inheritance:
