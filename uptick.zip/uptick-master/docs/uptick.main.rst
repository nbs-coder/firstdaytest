uptick.main module
==================

.. automodule:: uptick.main
   :members:
   :undoc-members:
   :show-inheritance:
