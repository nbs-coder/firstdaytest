uptick.ticket module
====================

.. automodule:: uptick.ticket
   :members:
   :undoc-members:
   :show-inheritance:
