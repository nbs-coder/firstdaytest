uptick.wallet module
====================

.. automodule:: uptick.wallet
   :members:
   :undoc-members:
   :show-inheritance:
