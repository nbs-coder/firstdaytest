uptick.callorders module
========================

.. automodule:: uptick.callorders
   :members:
   :undoc-members:
   :show-inheritance:
