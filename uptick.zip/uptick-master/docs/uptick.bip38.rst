uptick.bip38 module
===================

.. automodule:: uptick.bip38
   :members:
   :undoc-members:
   :show-inheritance:
