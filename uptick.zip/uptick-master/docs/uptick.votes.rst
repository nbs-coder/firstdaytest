uptick.votes module
===================

.. automodule:: uptick.votes
   :members:
   :undoc-members:
   :show-inheritance:
