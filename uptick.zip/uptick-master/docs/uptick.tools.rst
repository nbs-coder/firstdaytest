uptick.tools module
===================

.. automodule:: uptick.tools
   :members:
   :undoc-members:
   :show-inheritance:
