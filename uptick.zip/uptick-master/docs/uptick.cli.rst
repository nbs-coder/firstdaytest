uptick.cli module
=================

.. automodule:: uptick.cli
   :members:
   :undoc-members:
   :show-inheritance:
