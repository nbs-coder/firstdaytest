uptick.info module
==================

.. automodule:: uptick.info
   :members:
   :undoc-members:
   :show-inheritance:
