uptick.decorators module
========================

.. automodule:: uptick.decorators
   :members:
   :undoc-members:
   :show-inheritance:
