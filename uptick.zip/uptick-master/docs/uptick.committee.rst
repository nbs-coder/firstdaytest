uptick.committee module
=======================

.. automodule:: uptick.committee
   :members:
   :undoc-members:
   :show-inheritance:
