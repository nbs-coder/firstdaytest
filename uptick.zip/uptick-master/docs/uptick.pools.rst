uptick.pools module
===================

.. automodule:: uptick.pools
   :members:
   :undoc-members:
   :show-inheritance:
