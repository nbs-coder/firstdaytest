import unittest


class Testcases(unittest.TestCase):

    def test_temp(self):
        self.assertEqual(1, 1)


if __name__ == '__main__':
    unittest.main()
