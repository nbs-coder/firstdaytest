# Changelog
Note: version releases in the 0.x.y range may introduce breaking changes.

## 0.2.6

- patch: version bump
- patch: version bump for pypi

## 0.2.5

- patch: version bump

## 0.2.4

- patch: Update docs on releases
- patch: Update docs on releases
- patch: include semversioner

## 0.2.3


