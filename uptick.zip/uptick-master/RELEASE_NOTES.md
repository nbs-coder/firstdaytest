Release 0.2
================

Features:
---------

* Compatibility with pybitshares 0.2
* Colourful output
